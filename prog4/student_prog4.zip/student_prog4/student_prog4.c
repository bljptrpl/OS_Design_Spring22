//
//	EE 4374 Assignment #4 Shell (Test Function)
//	Author: ???
//

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include "student_argtok.h"
#include "student_exec.h"

int main()
{


	return 0;

}