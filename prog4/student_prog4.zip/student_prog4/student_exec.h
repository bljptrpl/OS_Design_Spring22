//
//	EE 4374 Assignment #4 Command Executer
//	Author: ???
//

int executeCmd(char **args);
