//
//	EE 4374 Assignment #4 Argument Tokenizer
//	Author: Michael McGarry
//

char ** argtok(char * argstr);